
package bean;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import connect.dbConnect;

public class registerBean
{
    private String username;
    private String password;
    private String amount;
    private String address;
    private String phone;
    private String aadhaar;
    private String accountType;
    private String gender;

    public void setAddress(String address) {
        this.address = address;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    
    public void setAadhaar(String aadhaar) {
        this.aadhaar = aadhaar;
    }

    
    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }
    
    public void setGender(String gender) {
        this.gender = gender;
    }


    public String getAddress() {
        return address;
    }

    public String getAmount() {
        return amount;
    }

    public String getPassword() {
        return password;
    }

    public String getPhone() {
        return phone;
    }

    public String getUsername() {
        return username;
    }
    
    public String getAadhaar() {
        return aadhaar;
    }

   	
   

    public String insert()
    {
        try
        {
            Connection con=dbConnect.getConnect();
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("select * from record where username='"+username+"'");
            if(rs.next())
            {
            	return "error";
            }
                        
            int x=st.executeUpdate("insert into record values('"+username+"','"+password+"',"+amount+",'"+address+"','"+phone+"','"+aadhaar+"','"+accountType+"','"+gender+"')");

            if(x>0)
            {
                return "register";
            }
            else
            	return "error.jsp";
           
           }catch(Exception e)
           {
               return "error.jsp";
           }
    }
}
